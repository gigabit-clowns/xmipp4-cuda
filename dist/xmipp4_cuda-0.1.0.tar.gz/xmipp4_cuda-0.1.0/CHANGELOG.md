# Release v0.1.0
Initial xmipp4-cuda release. Still work in progress.

- Up to date hardware interface implementation with the CUDA backend
- Efficient caching memory allocator based on PyTorch
